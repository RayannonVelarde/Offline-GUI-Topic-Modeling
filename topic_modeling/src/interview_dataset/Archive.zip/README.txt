# Synthetic Interview Dataset

This folder contains long-form synthetic interview transcripts designed for topic modeling and qualitative analysis.

## Design goals
- Repeated interview questions across files
- Long, natural-sounding participant responses
- Shared themes across interviews:
  - community and identity
  - technology and digital access
  - education/work challenges
  - stress, burnout, and mental health
  - support systems
  - community change
  - future goals
- Variation in profession, background, and lived experience

## File format
Each transcript uses:
- `Interviewer:` for prompts
- `Participant:` for responses

## Suggested use
This dataset is good for:
- preprocessing tests
- topic modeling across multiple files
- segmentation experiments
- screenshot/demo outputs
- LLM-based topic labeling

## Notes
These interviews are synthetic, not collected from real participants.
